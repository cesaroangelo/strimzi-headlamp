import React from 'react';
export declare function KafkaTopicList(): React.JSX.Element;
//# sourceMappingURL=KafkaTopicList.d.ts.map