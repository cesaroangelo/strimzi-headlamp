import React from 'react';
export declare function KafkaList(): React.JSX.Element;
//# sourceMappingURL=KafkaList.d.ts.map