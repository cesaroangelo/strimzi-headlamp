import React from 'react';
export declare function KafkaUserList(): React.JSX.Element;
//# sourceMappingURL=KafkaUserList.d.ts.map